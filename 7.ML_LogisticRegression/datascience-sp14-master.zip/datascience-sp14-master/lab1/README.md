## Lab 1 for Introduction to Data Science

Open [unix-utils.md](https://github.com/amplab/datascience-sp14/blob/master/lab1/unix-utils.md) to get started !
