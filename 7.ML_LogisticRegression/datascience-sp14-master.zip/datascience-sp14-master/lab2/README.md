## Lab 2 for Introduction to Data Science

Open [pandas.md](https://github.com/amplab/datascience-sp14/blob/master/lab2/pandas.md) to get started !
