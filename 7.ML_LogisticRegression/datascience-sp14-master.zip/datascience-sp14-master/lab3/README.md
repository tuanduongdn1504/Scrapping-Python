## Lab 3 for Introduction to Data Science

Open [refine-and-eda.md](https://github.com/amplab/datascience-sp14/blob/master/lab3/refine-and-eda.md) to get started !
