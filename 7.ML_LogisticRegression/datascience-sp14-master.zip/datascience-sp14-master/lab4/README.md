## Lab 4 for Introduction to Data Science

Open the IPython notebook on [joins](http://nbviewer.ipython.org/github/amplab/datascience-sp14/blob/master/lab4/joins.ipynb) to get started !
