## Lab 5 for Introduction to Data Science

Open the [IPython notebook](http://nbviewer.ipython.org/github/amplab/datascience-sp14/blob/master/lab5/lab5.ipynb) to get started !
