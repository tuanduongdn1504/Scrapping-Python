Open [r-lab.md](https://github.com/amplab/datascience-sp14/blob/master/lab6/r-lab.md) to get started !
