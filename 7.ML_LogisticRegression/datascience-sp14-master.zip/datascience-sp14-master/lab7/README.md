Lab 7
===============

Open the [iPython Notebook](http://goo.gl/nzDvVk) to get started
